export default function MintPage() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-black text-white">
      <h1 className="text-4xl font-bold">Mint Page (Replace with your real NFT Generator)</h1>
    </div>
  );
}